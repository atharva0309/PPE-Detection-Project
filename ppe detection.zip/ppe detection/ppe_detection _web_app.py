import streamlit as st
from ultralytics import YOLO
from inference import get_model
import supervision as sv
import cv2
import time
import tempfile
import numpy as np

# Define API_KEY or get it from the appropriate source
API_KEY = "iWeBrkfMuYbKHXSadeHn"

# Load the model with the API_KEY
model = get_model(model_id="ppe-dataset-for-workplace-safety/1", api_key=API_KEY)

# Streamlit UI
st.title("PPE Detection from Video")

# File uploader for video input
uploaded_video = st.file_uploader("Upload a video", type=["mp4", "avi", "mov"])

# Initialize state tracking
previous_detection_state = {
    'helmet': False,
    'vest': False,
    'goggles': False,
    'gloves': False
}

# Initialize flags to track alert messages
alert_flags = {
    'helmet': False,
    'vest': False,
    'goggles': False,
    'gloves': False
}

# Timestamp to control print frequency
last_print_time = time.time()

def process_frame(frame):
    global last_print_time, previous_detection_state, alert_flags

    # Run inference on the frame
    results = model.infer(frame)[0]

    # Load the results into the supervision Detections API
    detections = sv.Detections.from_inference(results)

    # Function to check for missing PPE
    def check_ppe_compliance(detections):
        global last_print_time, previous_detection_state, alert_flags
        
        detected_items = {'helmet': False, 'vest': False, 'goggles': False, 'gloves': False}

        # Access detection fields based on the actual structure
        for i in range(len(detections.class_id)):
            label = detections.data['class_name'][i]

            if label.lower() in detected_items:
                detected_items[label.lower()] = True

        # Determine if the equipment status has changed
        current_time = time.time()
        if current_time - last_print_time >= 5:  # Check if 5 seconds have passed
            for item in detected_items:
                if not detected_items[item]:
                    if previous_detection_state[item] and not alert_flags[item]:
                        st.write(f"Missing {item.capitalize()}.")
                        alert_flags[item] = True
                else:
                    alert_flags[item] = False

            # Update previous detection state
            for item in previous_detection_state:
                previous_detection_state[item] = detected_items[item]

            # Update the last print time
            last_print_time = current_time

    # Check for PPE compliance
    check_ppe_compliance(detections)

    # Create supervision annotators for visualizing results
    box_annotator = sv.BoxAnnotator()  # Updated from BoundingBoxAnnotator
    label_annotator = sv.LabelAnnotator()

    # Annotate the frame with inference results
    annotated_frame = box_annotator.annotate(scene=frame, detections=detections)
    annotated_frame = label_annotator.annotate(scene=annotated_frame, detections=detections)

    # Resize the frame to fit within the window without zooming in too much
    scale_percent = 30  # percentage of original size
    width = int(annotated_frame.shape[1] * scale_percent / 100)
    height = int(annotated_frame.shape[0] * scale_percent / 100)
    dim = (width, height)

    # Resize frame
    resized_frame = cv2.resize(annotated_frame, dim, interpolation=cv2.INTER_AREA)

    return resized_frame

# Process the uploaded video
if uploaded_video is not None:
    # Create a temporary file for the uploaded video
    with tempfile.NamedTemporaryFile(delete=False) as tmp_file:
        tmp_file.write(uploaded_video.read())
        tmp_file_path = tmp_file.name

    # Open the video file using OpenCV
    cap = cv2.VideoCapture(tmp_file_path)

    if not cap.isOpened():
        st.error("Error: Could not open video file.")
        exit()

    # Get original video frame width and height
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # Loop through the frames of the video
    frame_placeholder = st.empty()  # Placeholder for displaying video frames
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Process the frame and get the annotated frame
        annotated_frame = process_frame(frame)

        # Convert the frame to RGB for Streamlit display
        annotated_frame_rgb = cv2.cvtColor(annotated_frame, cv2.COLOR_BGR2RGB)

        # Display the frame in Streamlit as a video stream (using st.image)
        frame_placeholder.image(annotated_frame_rgb, channels="RGB", use_column_width=True)

    # Release video capture
    cap.release()

else:
    st.warning("Please upload a video to get started.")
