from ultralytics import YOLO
from inference import get_model
import supervision as sv
import cv2
import os

# Define API_KEY or get it from the appropriate source
API_KEY = "iWeBrkfMuYbKHXSadeHn"

# Load the model with the API_KEY
model = get_model(model_id="ppe-dataset-for-workplace-safety/1", api_key=API_KEY)

# Path to your single image
image_file ="C:\\Users\\athar\\OneDrive\\Desktop\\images (2).jpeg"  # Update with the correct path to your image
image = cv2.imread(image_file)

# Run inference on the image
results = model.infer(image)[0]

# Load the results into the supervision Detections API
detections = sv.Detections.from_inference(results)

# Function to check for missing PPE
def check_missing_ppe(detections):
    detected_person = False
    detected_items = {'helmet': False, 'vest': False, 'goggles': False, 'gloves': False}

    # Process the detections
    for i in range(len(detections.class_id)):
        label = detections.data['class_name'][i]
        # We don't need to print the positions or detections, just focus on the items
        if label == 'Person':
            detected_person = True
        elif label.lower() in detected_items:
            detected_items[label.lower()] = True

    # Only print missing PPE items, no other information
    if not detected_person:
        print("No person detected in the image.")
    else:
        if not detected_items['helmet']:
            print("Missing Helmet.")
        if not detected_items['vest']:
            print("Missing Vest.")
        if not detected_items['goggles']:
            print("Missing Goggles.")
        if not detected_items['gloves']:
            print("Missing Gloves.")

# Check for missing PPE
check_missing_ppe(detections)

# Create supervision annotators for visualizing results
box_annotator = sv.BoxAnnotator()  # Updated from BoundingBoxAnnotator
label_annotator = sv.LabelAnnotator()

# Annotate the image with inference results
annotated_image = box_annotator.annotate(scene=image, detections=detections)
annotated_image = label_annotator.annotate(scene=annotated_image, detections=detections)

# Display the annotated image
sv.plot_image(annotated_image)
